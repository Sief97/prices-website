import React from "react";
import { Link, useLocation } from "wouter";
import { useSidebar } from "@/components/ui/sidebar";
import { useLanguage } from "@/lib/useLanguage";
import {
  Home, DollarSign, Coins, Fuel, Zap, Leaf, Tv, MapPin,
  Cigarette, ShoppingCart, Car, Smartphone, Building2,
  BarChart3, TrendingUp, HardHat, Landmark, Heart, Wrench, Laptop
} from "lucide-react";
import {
  Sidebar, SidebarContent, SidebarGroup, SidebarGroupContent,
  SidebarGroupLabel, SidebarMenu, SidebarMenuButton, SidebarMenuItem,
} from "@/components/ui/sidebar";

const CATEGORIES = [
  { id:"currencies",    ar:"💱 العملات",           en:"Currencies",    icon: DollarSign },
  { id:"crypto",        ar:"₿ العملات الرقمية",    en:"Crypto",        icon: Coins },
  { id:"metals",        ar:"🥇 المعادن",           en:"Metals",        icon: Coins },
  { id:"fuel",          ar:"⛽ الوقود",             en:"Fuel",          icon: Fuel },
  { id:"electricity",   ar:"💡 الكهرباء",          en:"Electricity",   icon: Zap },
  { id:"vegetables",    ar:"🥬 الخضار",            en:"Produce",       icon: Leaf },
  { id:"subscriptions", ar:"📺 الاشتراكات",        en:"Subscriptions", icon: Tv },
  { id:"transport",     ar:"🚇 المواصلات",         en:"Transport",     icon: MapPin },
  { id:"tobacco",       ar:"🚬 التبغ",             en:"Tobacco",       icon: Cigarette },
  { id:"commodities",   ar:"🛒 السلع الأساسية",    en:"Commodities",   icon: ShoppingCart },
  { id:"automotive",    ar:"🚗 السيارات",          en:"Automotive",    icon: Car },
  { id:"tech",          ar:"📱 التكنولوجيا",       en:"Tech",          icon: Smartphone },
  { id:"govservices",   ar:"🏛️ الخدمات الحكومية", en:"Gov Services",  icon: Building2 },
  { id:"stocks",        ar:"📈 البورصة",           en:"Stocks",        icon: BarChart3 },
  { id:"bankrates",     ar:"🏦 أسعار الفائدة",     en:"Bank Rates",    icon: Landmark },
  { id:"construction",  ar:"🏗️ البناء",           en:"Construction",  icon: HardHat },
];

export function AppSidebar() {
  const [location] = useLocation();
  const { setOpenMobile } = useSidebar();
  const { isArabic } = useLanguage();
  const close = () => setOpenMobile(false);

  return (
    <Sidebar
      variant="inset"
      side={isArabic ? "right" : "left"}
      className="border-border bg-sidebar"
    >
      <SidebarContent className="px-2 py-4 no-scrollbar">

        {/* Home */}
        <SidebarGroup>
          <SidebarGroupContent>
            <SidebarMenu>
              <SidebarMenuItem>
                <SidebarMenuButton
                  asChild isActive={location === "/"} onClick={close}
                  className="rounded-lg data-[active=true]:bg-foreground data-[active=true]:text-background hover:bg-muted transition-all text-sm font-medium"
                >
                  <Link href="/">
                    <Home className="w-4 h-4" />
                    <span>{isArabic ? 'الرئيسية' : 'Home'}</span>
                  </Link>
                </SidebarMenuButton>
              </SidebarMenuItem>
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>

        <div className="my-2 border-t border-border" />

        {/* Categories */}
        <SidebarGroup>
          <SidebarGroupLabel className="text-[10px] uppercase tracking-widest text-muted-foreground/60 font-bold mb-2 px-2">
            {isArabic ? `القطاعات (${CATEGORIES.length})` : `Sectors (${CATEGORIES.length})`}
          </SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu className="space-y-0.5">
              {CATEGORIES.map((cat) => {
                const path = `/category/${cat.id}`;
                const isActive = location === path;
                return (
                  <SidebarMenuItem key={cat.id}>
                    <SidebarMenuButton
                      asChild isActive={isActive} onClick={close}
                      className="rounded-lg data-[active=true]:bg-foreground data-[active=true]:text-background hover:bg-muted transition-all text-sm"
                      style={isActive ? { borderRight: isArabic ? '3px solid #D72638' : undefined, borderLeft: !isArabic ? '3px solid #D72638' : undefined } : {}}
                    >
                      <Link href={path}>
                        <cat.icon className="w-4 h-4 shrink-0" />
                        <span className="truncate">{isArabic ? cat.ar : cat.en}</span>
                      </Link>
                    </SidebarMenuButton>
                  </SidebarMenuItem>
                );
              })}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>

      </SidebarContent>
    </Sidebar>
  );
}
