import React from "react";
import { Link } from "wouter";
import { useCurrentPrices } from "@/hooks/use-prices";
import { useLanguage } from "@/lib/useLanguage";

export function Marquee() {
  const { currentPrices, isLoading } = useCurrentPrices();
  const { isArabic } = useLanguage();

  if (isLoading || !currentPrices || currentPrices.length === 0) {
    return (
      <div className="flex-1 h-full flex items-center px-4 border-s border-border">
        <div className="w-full h-3 bg-muted/50 rounded animate-pulse" />
      </div>
    );
  }

  const topMovers = [...currentPrices]
    .sort((a, b) => Math.abs(b.changePercent) - Math.abs(a.changePercent))
    .slice(0, 14);
  const tickerItems = [...topMovers, ...topMovers];

  return (
    <div className="flex-1 h-full overflow-hidden flex items-center relative border-s border-border bg-card">
      {/* fade edges */}
      <div className={`absolute ${isArabic ? 'right-0' : 'left-0'} top-0 bottom-0 w-10 ${isArabic ? 'bg-gradient-to-l' : 'bg-gradient-to-r'} from-card to-transparent z-10 pointer-events-none`} />
      <div className={`absolute ${isArabic ? 'left-0' : 'right-0'} top-0 bottom-0 w-10 ${isArabic ? 'bg-gradient-to-r' : 'bg-gradient-to-l'} from-card to-transparent z-10 pointer-events-none`} />

      <div className={`flex w-max animate-marquee ${isArabic ? 'flex-row-reverse' : ''}`}>
        {tickerItems.map((item, idx) => {
          const isUp = item.changePercent > 0;
          const isDown = item.changePercent < 0;
          return (
            <Link
              key={`${item.item_id}-${idx}`}
              href={`/product/${encodeURIComponent(item.item_id)}`}
              className="flex items-center gap-2.5 px-5 border-s border-border hover:bg-muted/30 transition-colors py-2 cursor-pointer whitespace-nowrap"
            >
              <span className="text-sm font-medium text-foreground/80">{item.nameAr}</span>
              <span className="text-sm font-bold text-foreground tabular-nums">{item.price.toLocaleString()}</span>
              <span className={`text-xs font-bold tabular-nums px-1.5 py-0.5 rounded-full ${isUp ? 'badge-up' : isDown ? 'badge-down' : 'badge-flat'}`}>
                {isUp ? '▲' : isDown ? '▼' : '—'}{Math.abs(item.changePercent).toFixed(1)}%
              </span>
            </Link>
          );
        })}
      </div>
    </div>
  );
}
