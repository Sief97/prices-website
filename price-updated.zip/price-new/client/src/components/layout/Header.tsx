import React, { useState } from "react";
import { Link, useLocation } from "wouter";
import { Search, X, Globe2, Menu } from "lucide-react";
import { useCurrentPrices } from "@/hooks/use-prices";
import { useLanguage } from "@/lib/useLanguage";
import { useSidebar } from "@/components/ui/sidebar";

export function Header() {
  const [q, setQ] = useState("");
  const [focused, setFocused] = useState(false);
  const [, setLocation] = useLocation();
  const { currentPrices } = useCurrentPrices();
  const { toggleSidebar } = useSidebar();
  const { isArabic, setLanguage } = useLanguage();

  const results = React.useMemo(() => {
    if (!q.trim() || !currentPrices) return [];
    const lq = q.toLowerCase();
    return currentPrices
      .filter(i => i.nameAr.includes(q) || i.nameAr.toLowerCase().includes(lq) || i.category.toLowerCase().includes(lq))
      .slice(0, 6);
  }, [q, currentPrices]);

  return (
    <header className="sticky top-12 md:top-14 z-40 w-full border-b border-border bg-card/90 backdrop-blur-xl">
      <div className="flex h-12 md:h-14 items-center px-3 md:px-5 gap-3">

        {/* Mobile sidebar toggle */}
        <button onClick={toggleSidebar} className="md:hidden p-1.5 -ms-1 text-muted-foreground hover:text-foreground transition-colors">
          <Menu className="w-5 h-5" />
        </button>

        {/* Search */}
        <div className="flex-1 max-w-xl relative">
          <div className={`relative flex items-center rounded-lg border transition-all duration-200 ${focused ? 'border-foreground ring-2 ring-foreground/8 bg-background' : 'border-border bg-muted/40 hover:bg-muted/60'}`}>
            <Search className={`absolute ${isArabic ? 'right-3' : 'left-3'} w-4 h-4 text-muted-foreground pointer-events-none`} />
            <input
              type="text"
              className={`w-full h-9 ${isArabic ? 'pr-9 pl-9' : 'pl-9 pr-9'} bg-transparent outline-none text-sm placeholder:text-muted-foreground/60`}
              placeholder={isArabic ? "ابحث... دولار، ذهب، بنزين..." : "Search... dollar, gold, fuel..."}
              value={q}
              onChange={e => setQ(e.target.value)}
              onFocus={() => setFocused(true)}
              onBlur={() => setTimeout(() => setFocused(false), 180)}
              dir={isArabic ? 'rtl' : 'ltr'}
            />
            {q && (
              <button onClick={() => setQ("")} className={`absolute ${isArabic ? 'left-3' : 'right-3'} text-muted-foreground hover:text-foreground`}>
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          {/* Dropdown */}
          {focused && q && (
            <div className={`absolute ${isArabic ? 'right-0' : 'left-0'} top-full mt-1.5 w-full bg-card border border-border rounded-lg shadow-xl overflow-hidden z-50`}>
              {results.length > 0 ? (
                <div className="p-1.5">
                  {results.map(item => {
                    const up = item.changePercent > 0, dn = item.changePercent < 0;
                    return (
                      <button
                        key={item.item_id}
                        onClick={() => { setLocation(`/product/${encodeURIComponent(item.item_id)}`); setQ(""); }}
                        className="w-full flex items-center justify-between p-2.5 hover:bg-muted/60 rounded-md transition-colors"
                        dir={isArabic ? 'rtl' : 'ltr'}
                      >
                        <div className="text-start">
                          <div className="text-sm font-semibold">{item.nameAr}</div>
                          <div className="text-xs text-muted-foreground">{item.category}</div>
                        </div>
                        <div className="flex items-center gap-2">
                          <span className="text-sm font-bold tabular-nums">{item.price.toLocaleString()}</span>
                          <span className={`text-xs font-bold px-1.5 py-0.5 rounded-full tabular-nums ${up ? 'badge-up' : dn ? 'badge-down' : 'badge-flat'}`}>
                            {up ? '▲' : dn ? '▼' : '—'}{Math.abs(item.changePercent).toFixed(1)}%
                          </span>
                        </div>
                      </button>
                    );
                  })}
                </div>
              ) : (
                <div className="p-6 text-center text-sm text-muted-foreground">
                  {isArabic ? 'لا توجد نتائج' : 'No results found'}
                </div>
              )}
            </div>
          )}
        </div>

        {/* Language toggle */}
        <button
          onClick={() => setLanguage(isArabic ? 'en' : 'ar')}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-border text-xs font-bold text-muted-foreground hover:text-foreground hover:bg-muted transition-all"
        >
          <Globe2 className="w-3.5 h-3.5" />
          <span>{isArabic ? 'EN' : 'عر'}</span>
        </button>

      </div>
    </header>
  );
}
