import React, { useEffect } from "react";
import { Link } from "wouter";
import { SidebarProvider } from "@/components/ui/sidebar";
import { useLanguage } from "@/lib/useLanguage";
import { AppSidebar } from "./AppSidebar";
import { Header } from "./Header";
import { Marquee } from "./Marquee";

export function AppLayout({ children }: { children: React.ReactNode }) {
  const { isArabic } = useLanguage();

  useEffect(() => {
    document.documentElement.dir  = isArabic ? 'rtl' : 'ltr';
    document.documentElement.lang = isArabic ? 'ar' : 'en';
  }, [isArabic]);

  const style = {
    "--sidebar-width": "15rem",
    "--sidebar-width-icon": "3.5rem",
  } as React.CSSProperties;

  return (
    <SidebarProvider style={style}>
      <div className="flex h-screen w-full bg-background overflow-hidden text-foreground">
        <AppSidebar />

        <div className="flex flex-col flex-1 min-w-0 overflow-hidden">
          {/* Top bar: Logo + Ticker */}
          <div className="h-12 md:h-14 bg-card border-b border-border flex items-center flex-shrink-0 sticky top-0 z-40">
            {/* Logo */}
            <Link href="/" className="flex items-center gap-2.5 px-4 md:px-5 flex-shrink-0 group">
              {/* red square mark */}
              <div className="w-6 h-6 bg-foreground rounded-[5px] flex items-center justify-center flex-shrink-0">
                <span style={{ color: '#D72638', fontSize: 12, fontWeight: 900, lineHeight: 1 }}>₳</span>
              </div>
              <div className="flex flex-col leading-none">
                <span className="font-black text-sm text-foreground leading-tight">
                  Price<span style={{ color: '#D72638' }}>.eg</span>
                </span>
                <span className="text-[10px] text-muted-foreground leading-tight hidden md:block">
                  {isArabic ? 'أسعار مصر' : 'Egypt Prices'}
                </span>
              </div>
            </Link>

            {/* live dot */}
            <div className="flex items-center gap-1.5 px-3 flex-shrink-0 hidden sm:flex">
              <span className="live-dot" />
              <span className="text-[10px] text-muted-foreground font-medium">
                {isArabic ? 'مباشر' : 'Live'}
              </span>
            </div>

            {/* Ticker */}
            <Marquee />
          </div>

          <Header />

          <main className="flex-1 overflow-y-auto overflow-x-hidden no-scrollbar bg-background">
            <div className="max-w-6xl mx-auto p-3 md:p-5 lg:p-7 w-full">
              {children}
            </div>
          </main>
        </div>
      </div>
    </SidebarProvider>
  );
}
