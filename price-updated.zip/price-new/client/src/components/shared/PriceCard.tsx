import React from "react";
import { Link } from "wouter";
import { TrendingUp, TrendingDown, Minus } from "lucide-react";
import { CurrentPrice } from "@/hooks/use-prices";

interface PriceCardProps {
  item: CurrentPrice;
  featured?: boolean;
  index?: number;
}

export function PriceCard({ item, featured = false, index = 0 }: PriceCardProps) {
  const isUp = item.changePercent > 0;
  const isDown = item.changePercent < 0;

  const fmt = (p: number) => {
    if (p >= 1_000_000) return (p / 1_000_000).toFixed(2) + 'M';
    if (p >= 1_000)     return p.toLocaleString();
    if (p < 1)          return p.toFixed(4);
    return p.toLocaleString(undefined, { maximumFractionDigits: 2 });
  };

  return (
    <Link
      href={`/product/${encodeURIComponent(item.item_id)}`}
      className={`fu d${Math.min(index + 1, 6)} block rounded-xl border border-border bg-card hover-elevate group cursor-pointer transition-all ${featured ? 'p-5' : 'p-4'}`}
    >
      <div className="flex flex-col h-full gap-3">
        {/* top row */}
        <div className="flex items-start justify-between gap-2">
          <div className="min-w-0">
            <p className="text-xs text-muted-foreground mb-0.5 truncate">{item.category}</p>
            <h3 className="text-sm font-bold text-foreground line-clamp-2 group-hover:text-primary transition-colors leading-snug">
              {item.nameAr}
            </h3>
          </div>
          {/* change badge */}
          <span className={`flex items-center gap-0.5 text-xs font-bold px-2 py-1 rounded-full whitespace-nowrap shrink-0 ${isUp ? 'badge-up' : isDown ? 'badge-down' : 'badge-flat'}`}>
            {isUp ? <TrendingUp className="w-3 h-3" /> : isDown ? <TrendingDown className="w-3 h-3" /> : <Minus className="w-3 h-3" />}
            {Math.abs(item.changePercent).toFixed(2)}%
          </span>
        </div>

        {/* price */}
        <div className="mt-auto">
          <p className={`font-black tabular-nums text-foreground leading-none ${featured ? 'text-3xl' : 'text-2xl'}`}>
            {fmt(item.price)}
          </p>
          <p className="text-xs text-muted-foreground mt-1">{item.unit}</p>
        </div>
      </div>
    </Link>
  );
}
