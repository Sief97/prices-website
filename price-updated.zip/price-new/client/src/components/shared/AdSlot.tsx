import React from "react";

interface AdSlotProps {
  className?: string;
  variant?: "banner" | "sidebar";
}

export function AdSlot({ className = "", variant = "banner" }: AdSlotProps) {
  return (
    <div className={`relative flex flex-col items-center justify-center bg-muted/30 border border-dashed border-border rounded-xl text-muted-foreground overflow-hidden group ${variant === "banner" ? "h-24 w-full" : "h-56 w-full"} ${className}`}>
      <div className="flex flex-col items-center gap-1.5 opacity-40 group-hover:opacity-70 transition-opacity">
        <span className="text-lg">📢</span>
        <span className="text-xs font-medium uppercase tracking-widest">Advertisement</span>
      </div>
      {/* corner accents */}
      <div className="absolute top-0 start-0 w-2 h-2 border-t border-s border-border/60 rounded-ss-sm" />
      <div className="absolute top-0 end-0 w-2 h-2 border-t border-e border-border/60 rounded-se-sm" />
      <div className="absolute bottom-0 start-0 w-2 h-2 border-b border-s border-border/60 rounded-es-sm" />
      <div className="absolute bottom-0 end-0 w-2 h-2 border-b border-e border-border/60 rounded-ee-sm" />
    </div>
  );
}
