import React from "react";
import { useRoute, Link } from "wouter";
import { useCurrentPrices } from "@/hooks/use-prices";
import { useLanguage } from "@/lib/useLanguage";
import { PriceCard } from "@/components/shared/PriceCard";
import { AdSlot } from "@/components/shared/AdSlot";
import { ArrowLeft, TrendingUp, TrendingDown } from "lucide-react";

const CATEGORY_MAP: Record<string, string> = {
  currencies:    "💱 العملات",
  crypto:        "₿ العملات الرقمية",
  metals:        "🥇 المعادن",
  fuel:          "⛽ الوقود",
  electricity:   "💡 الكهرباء",
  vegetables:    "🥬 الخضار",
  subscriptions: "📺 الاشتراكات",
  transport:     "🚇 المواصلات",
  tobacco:       "🚬 التبغ",
  commodities:   "🛒 السلع الأساسية",
  automotive:    "🚗 السيارات",
  tech:          "📱 التكنولوجيا",
  govservices:   "🏛️ الخدمات الحكومية",
  stocks:        "📈 البورصة",
  bankrates:     "🏦 أسعار الفائدة",
  construction:  "🏗️ البناء",
};

const CAT_EN: Record<string, string> = {
  currencies:"Currencies", crypto:"Crypto", metals:"Metals", fuel:"Fuel",
  electricity:"Electricity", vegetables:"Produce", subscriptions:"Subscriptions",
  transport:"Transport", tobacco:"Tobacco", commodities:"Commodities",
  automotive:"Automotive", tech:"Tech", govservices:"Gov Services",
  stocks:"Stocks", bankrates:"Bank Rates", construction:"Construction",
};

export default function Category() {
  const [, params] = useRoute("/category/:id");
  const catId = params?.id || "";
  const categoryName = CATEGORY_MAP[catId];
  const { currentPrices, isLoading } = useCurrentPrices();
  const { isArabic, t } = useLanguage();

  if (!categoryName) {
    return (
      <div className="text-center py-20">
        <h2 className="text-xl font-bold mb-4">{isArabic ? 'القسم غير موجود' : 'Category not found'}</h2>
        <Link href="/" className="text-primary hover:underline">{t('back_to_market')}</Link>
      </div>
    );
  }

  if (isLoading) {
    return (
      <div className="space-y-5 animate-pulse">
        <div className="h-20 bg-muted rounded-xl" />
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3">
          {[...Array(6)].map((_, i) => <div key={i} className="h-28 bg-muted rounded-xl" />)}
        </div>
      </div>
    );
  }

  const items = currentPrices?.filter(i => i.category === categoryName) || [];
  const advancing = items.filter(i => i.changePercent > 0).length;
  const declining = items.filter(i => i.changePercent < 0).length;
  const displayName = isArabic ? categoryName : CAT_EN[catId] || catId;

  return (
    <div className="space-y-6 pb-10">

      {/* header */}
      <div className="fu d1">
        <Link href="/" className="inline-flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground transition-colors mb-4 group">
          <ArrowLeft className="w-4 h-4 group-hover:-translate-x-0.5 transition-transform" style={isArabic ? { transform: 'rotate(180deg)' } : {}} />
          {t('back_to_market')}
        </Link>

        <div className="flex items-center gap-3">
          <div className="w-1.5 h-8 rounded-full" style={{ background: '#D72638' }} />
          <div>
            <h1 className="text-2xl md:text-3xl font-black text-foreground">{displayName}</h1>
            <p className="text-xs text-muted-foreground mt-0.5">
              {items.length} {isArabic ? 'سعر مسجل' : 'prices tracked'}
            </p>
          </div>
        </div>
      </div>

      {/* summary bar */}
      {items.length > 0 && (
        <div className="fu d2 flex items-center gap-4 p-3 rounded-lg border border-border bg-muted/30 text-sm">
          <div className="flex items-center gap-1.5">
            <TrendingUp className="w-4 h-4" style={{ color: '#16a34a' }} />
            <span className="font-bold" style={{ color: '#16a34a' }}>{advancing}</span>
            <span className="text-muted-foreground text-xs">{isArabic ? 'صاعد' : 'up'}</span>
          </div>
          <div className="w-px h-4 bg-border" />
          <div className="flex items-center gap-1.5">
            <TrendingDown className="w-4 h-4" style={{ color: '#D72638' }} />
            <span className="font-bold" style={{ color: '#D72638' }}>{declining}</span>
            <span className="text-muted-foreground text-xs">{isArabic ? 'هابط' : 'down'}</span>
          </div>
          <div className="w-px h-4 bg-border" />
          <div className="flex items-center gap-1.5">
            <span className="font-bold text-foreground">{items.length}</span>
            <span className="text-muted-foreground text-xs">{isArabic ? 'إجمالي' : 'total'}</span>
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        {/* cards */}
        <div className="lg:col-span-3">
          {items.length > 0 ? (
            <div className="grid grid-cols-2 sm:grid-cols-2 md:grid-cols-3 gap-3">
              {items.map((item, i) => <PriceCard key={item.item_id} item={item} index={i} />)}
            </div>
          ) : (
            <div className="py-20 text-center border border-dashed border-border rounded-xl">
              <p className="text-2xl font-black mb-2">{isArabic ? 'قريباً' : 'Coming Soon'}</p>
              <p className="text-sm text-muted-foreground">{isArabic ? 'نعمل على توفير بيانات هذا القسم' : 'Working on data for this section'}</p>
            </div>
          )}
        </div>

        {/* sidebar */}
        <div className="space-y-4">
          <AdSlot variant="sidebar" />
          {items.length > 0 && (
            <div className="p-4 rounded-xl border border-border bg-card">
              <h3 className="text-sm font-bold mb-3 flex items-center gap-2">
                <div className="w-1 h-3.5 rounded-full" style={{ background: '#D72638' }} />
                {isArabic ? 'ملخص القسم' : 'Summary'}
              </h3>
              <div className="space-y-2.5 text-sm">
                {[
                  { label: isArabic ? 'إجمالي' : 'Total', val: items.length },
                  { label: isArabic ? 'صاعد' : 'Advancing', val: advancing, color: '#16a34a' },
                  { label: isArabic ? 'هابط' : 'Declining', val: declining, color: '#D72638' },
                  { label: isArabic ? 'أعلى سعر' : 'Highest', val: Math.max(...items.map(i => i.price)).toLocaleString() },
                  { label: isArabic ? 'أقل سعر' : 'Lowest',  val: Math.min(...items.map(i => i.price)).toLocaleString() },
                ].map(row => (
                  <div key={row.label} className="flex justify-between items-center border-b border-border pb-2 last:border-0 last:pb-0">
                    <span className="text-muted-foreground text-xs">{row.label}</span>
                    <span className="font-bold text-sm tabular-nums" style={row.color ? { color: row.color } : {}}>{row.val}</span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
