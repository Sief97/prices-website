import React from "react";
import { useCurrentPrices } from "@/hooks/use-prices";
import { useLanguage } from "@/lib/useLanguage";
import { Link } from "wouter";
import { PriceCard } from "@/components/shared/PriceCard";
import { AlertCircle, ArrowRight } from "lucide-react";

const FEATURED_IDS = ["cur_usd_bank","metal_gold21","fuel_95","crypto_btc","stock_egx30","bank_corridor"];

const QUICK_CATS = [
  { id:"currencies",    ar:"💱 العملات",        en:"Currencies"    },
  { id:"metals",        ar:"🥇 المعادن",        en:"Metals"        },
  { id:"fuel",          ar:"⛽ الوقود",          en:"Fuel"          },
  { id:"crypto",        ar:"₿ كريبتو",          en:"Crypto"        },
  { id:"commodities",   ar:"🛒 السلع",          en:"Commodities"   },
  { id:"stocks",        ar:"📈 البورصة",         en:"Stocks"        },
  { id:"subscriptions", ar:"📺 اشتراكات",       en:"Subscriptions" },
  { id:"bankrates",     ar:"🏦 فوائد البنوك",   en:"Bank Rates"    },
  { id:"transport",     ar:"🚇 مواصلات",        en:"Transport"     },
];

export default function Home() {
  const { currentPrices, isLoading } = useCurrentPrices();
  const { isArabic, t } = useLanguage();

  if (isLoading) {
    return (
      <div className="space-y-5 animate-pulse">
        <div className="h-16 bg-muted rounded-xl" />
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
          {[...Array(6)].map((_, i) => <div key={i} className="h-28 bg-muted rounded-xl" />)}
        </div>
      </div>
    );
  }

  if (!currentPrices || currentPrices.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center h-[50vh] text-center">
        <AlertCircle className="w-10 h-10 text-muted-foreground/30 mb-3" />
        <h2 className="text-lg font-bold mb-1">{t('no_data')}</h2>
        <p className="text-sm text-muted-foreground">{t('unable_to_load')}</p>
      </div>
    );
  }

  const featured = FEATURED_IDS.map(id => currentPrices.find(p => p.item_id === id)).filter(Boolean) as typeof currentPrices;
  const star = featured[0];
  const rest = featured.slice(1);

  // latest updates — top movers
  const topMovers = [...currentPrices].sort((a,b) => Math.abs(b.changePercent) - Math.abs(a.changePercent)).slice(0, 8);

  return (
    <div className="space-y-7 pb-10">

      {/* ── HERO: big number ── */}
      {star && (
        <Link href={`/product/${encodeURIComponent(star.item_id)}`}>
          <div className="fu d1 rounded-xl border border-border bg-card p-5 md:p-6 cursor-pointer group hover-elevate">
            {/* overline */}
            <div className="flex items-center gap-2 mb-3">
              <div className="w-1 h-4 rounded-full" style={{ background: '#D72638' }} />
              <span className="text-xs font-bold uppercase tracking-widest text-muted-foreground">
                {isArabic ? 'أبرز المؤشرات' : 'Key Indicators'}
              </span>
              <span className="live-dot ms-auto" />
              <span className="text-[10px] text-muted-foreground">{isArabic ? 'مباشر' : 'Live'}</span>
            </div>

            <p className="text-xs text-muted-foreground mb-1">{star.nameAr} · {star.unit}</p>
            <p className="text-5xl md:text-6xl font-black tabular-nums text-foreground leading-none mb-3 group-hover:opacity-80 transition-opacity" style={{ letterSpacing: '-2px' }}>
              {star.price.toLocaleString()}
            </p>

            <div className="flex items-center gap-3 flex-wrap">
              <span className={`flex items-center gap-1 text-sm font-bold px-3 py-1.5 rounded-full ${star.changePercent > 0 ? 'badge-up' : star.changePercent < 0 ? 'badge-down' : 'badge-flat'}`}>
                {star.changePercent > 0 ? '▲' : star.changePercent < 0 ? '▼' : '—'}
                {Math.abs(star.changePercent).toFixed(2)}%
              </span>
              <span className="text-xs text-muted-foreground">
                {isArabic ? 'مقارنة بآخر تحديث' : 'vs last update'}
              </span>
            </div>
          </div>
        </Link>
      )}

      {/* ── FEATURED GRID 2×2+1 ── */}
      <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
        {rest.map((item, i) => (
          <PriceCard key={item.item_id} item={item} index={i + 1} />
        ))}
      </div>

      {/* ── QUICK CATEGORY LINKS ── */}
      <div>
        <div className="flex items-center gap-2 mb-3">
          <div className="w-1 h-4 rounded-full" style={{ background: '#D72638' }} />
          <h2 className="text-sm font-bold uppercase tracking-widest text-muted-foreground">
            {isArabic ? 'تصفح الأقسام' : 'Browse Categories'}
          </h2>
        </div>
        <div className="grid grid-cols-3 gap-2">
          {QUICK_CATS.map(cat => (
            <Link key={cat.id} href={`/category/${cat.id}`}>
              <div className="fu rounded-lg border border-border bg-card px-3 py-2.5 text-center text-xs font-semibold text-foreground hover:bg-muted hover:border-foreground/20 transition-all cursor-pointer leading-snug">
                {isArabic ? cat.ar : cat.en}
              </div>
            </Link>
          ))}
        </div>
        <Link href="/category/currencies">
          <div className="mt-2 w-full flex items-center justify-center gap-2 rounded-lg border border-foreground bg-foreground text-background px-4 py-2.5 text-sm font-bold hover:opacity-90 transition-opacity cursor-pointer">
            {isArabic ? 'كل الأقسام' : 'All Categories'}
            <ArrowRight className="w-4 h-4" style={isArabic ? { transform: 'rotate(180deg)' } : {}} />
          </div>
        </Link>
      </div>

      {/* ── TOP MOVERS ── */}
      <div>
        <div className="flex items-center gap-2 mb-3">
          <div className="w-1 h-4 rounded-full" style={{ background: '#D72638' }} />
          <h2 className="text-sm font-bold uppercase tracking-widest text-muted-foreground">
            {isArabic ? 'الأكثر تحركاً' : 'Top Movers'}
          </h2>
        </div>
        {/* table header */}
        <div className="flex items-center gap-3 px-3 pb-2 border-b-2 border-foreground text-[10px] font-bold uppercase tracking-widest text-muted-foreground/60">
          <span className="w-5">#</span>
          <span className="flex-1">{isArabic ? 'البند' : 'Item'}</span>
          <span className="w-16 text-center">{isArabic ? 'تغيير' : 'Change'}</span>
          <span className="w-20 text-end">{isArabic ? 'السعر' : 'Price'}</span>
        </div>
        {topMovers.map((item, i) => {
          const isUp = item.changePercent > 0, isDown = item.changePercent < 0;
          return (
            <Link key={item.item_id} href={`/product/${encodeURIComponent(item.item_id)}`}>
              <div className={`fu d${Math.min(i+1,6)} flex items-center gap-3 px-3 py-3 border-b border-border hover:bg-muted/50 transition-colors cursor-pointer`}>
                <span className="w-5 text-[11px] text-muted-foreground/40 tabular-nums">{i + 1}</span>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-semibold text-foreground truncate">{item.nameAr}</p>
                  <p className="text-[11px] text-muted-foreground truncate">{item.unit}</p>
                </div>
                <span className={`w-16 text-center text-xs font-bold px-2 py-1 rounded-full tabular-nums ${isUp ? 'badge-up' : isDown ? 'badge-down' : 'badge-flat'}`}>
                  {isUp ? '▲' : isDown ? '▼' : '—'}{Math.abs(item.changePercent).toFixed(1)}%
                </span>
                <span className="w-20 text-end text-sm font-black tabular-nums text-foreground">
                  {item.price >= 1_000_000 ? (item.price / 1_000_000).toFixed(2) + 'M' : item.price.toLocaleString()}
                </span>
              </div>
            </Link>
          );
        })}
      </div>

    </div>
  );
}
