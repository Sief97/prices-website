import React, { useState, useMemo, useEffect } from "react";
import { useRoute, Link } from "wouter";
import { usePriceHistory } from "@/hooks/use-prices";
import { useLanguage } from "@/lib/useLanguage";
import { AdSlot } from "@/components/shared/AdSlot";
import { ArrowLeft, TrendingUp, TrendingDown, Minus, Info } from "lucide-react";
import {
  AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip,
  ResponsiveContainer,
} from "recharts";
import { format, subYears, isAfter } from "date-fns";

type TF = '1Y' | 'ALL';

const RED   = '#D72638';
const GREEN = '#16a34a';

export default function ProductDetail() {
  const [, params]  = useRoute("/product/:id");
  const id          = params?.id ? decodeURIComponent(params.id) : "";
  const { history, isLoading } = usePriceHistory(id);
  const { isArabic, t } = useLanguage();
  const [tf, setTf] = useState<TF>('ALL');

  useEffect(() => { window.scrollTo(0, 0); }, [id]);

  const chartData = useMemo(() => {
    if (!history?.events) return [];
    let data = history.events;
    if (tf === '1Y') {
      const cutoff = subYears(new Date(), 1);
      data = data.filter(e => isAfter(new Date(e.date), cutoff));
    }
    return data.map(e => ({
      date:          e.date,
      formattedDate: format(new Date(e.date), "MMM dd, yyyy"),
      price:         e.price,
    }));
  }, [history, tf]);

  if (isLoading) {
    return (
      <div className="animate-pulse space-y-5">
        <div className="h-28 bg-muted rounded-xl" />
        <div className="h-80 bg-muted rounded-xl" />
      </div>
    );
  }

  if (!history?.latest) {
    return (
      <div className="text-center py-20">
        <h2 className="text-xl font-bold mb-3">{t('product_not_found')}</h2>
        <Link href="/" className="text-primary hover:underline">{t('back_to_market')}</Link>
      </div>
    );
  }

  const { latest, change, changePercent } = history;
  const isUp   = change > 0;
  const isDown = change < 0;
  const accentColor = isUp ? GREEN : isDown ? RED : '#888';
  const fmt = (p: number) => {
    if (p >= 1_000_000) return (p / 1_000_000).toFixed(2) + 'M';
    if (p >= 1_000)     return p.toLocaleString();
    if (p < 1)          return p.toFixed(4);
    return p.toLocaleString(undefined, { maximumFractionDigits: 2 });
  };

  const CustomTooltip = ({ active, payload }: any) => {
    if (!active || !payload?.length) return null;
    return (
      <div className="bg-card border border-border p-3 rounded-lg shadow-xl text-sm">
        <p className="text-muted-foreground text-xs mb-1">{payload[0].payload.formattedDate}</p>
        <p className="text-xl font-black tabular-nums">{fmt(payload[0].value)}</p>
      </div>
    );
  };

  const high = chartData.length ? Math.max(...chartData.map(d => d.price)) : 0;
  const low  = chartData.length ? Math.min(...chartData.map(d => d.price)) : 0;

  return (
    <div className="space-y-5 pb-16">

      {/* back */}
      <Link href="/" className="inline-flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground transition-colors group fu d1">
        <ArrowLeft className="w-4 h-4 group-hover:-translate-x-0.5 transition-transform" style={isArabic ? { transform:'rotate(180deg)' } : {}} />
        {t('back_to_market')}
      </Link>

      <div className="grid grid-cols-1 xl:grid-cols-4 gap-5">
        <div className="xl:col-span-3 space-y-5">

          {/* hero card */}
          <div className="fu d1 rounded-xl border border-border bg-card p-5 md:p-7 relative overflow-hidden">
            <div className="absolute end-0 top-0 w-48 h-48 rounded-full blur-3xl opacity-5 pointer-events-none"
              style={{ background: accentColor }} />

            <div className="relative z-10" dir={isArabic ? 'rtl' : 'ltr'}>
              {/* category + name */}
              <div className="flex items-center gap-2 mb-2">
                <div className="w-1 h-4 rounded-full" style={{ background: RED }} />
                <span className="text-xs text-muted-foreground font-medium">{latest.category}</span>
              </div>
              <h1 className="text-2xl md:text-3xl font-black text-foreground mb-5 leading-tight">
                {latest.nameAr}
              </h1>

              {/* price + change */}
              <div className="flex items-end gap-4 flex-wrap">
                <p className="text-4xl md:text-5xl font-black tabular-nums text-foreground leading-none" style={{ letterSpacing: '-1px' }}>
                  {fmt(latest.price)}
                </p>
                <div className="flex flex-col gap-1 mb-1">
                  <span className="text-sm text-muted-foreground">{latest.unit}</span>
                  <span className={`flex items-center gap-1.5 text-sm font-bold px-3 py-1 rounded-full ${isUp ? 'badge-up' : isDown ? 'badge-down' : 'badge-flat'}`}>
                    {isUp ? <TrendingUp className="w-4 h-4" /> : isDown ? <TrendingDown className="w-4 h-4" /> : <Minus className="w-4 h-4" />}
                    {isUp ? '+' : ''}{change.toFixed(2)}  ({isUp ? '+' : ''}{changePercent.toFixed(2)}%)
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* chart */}
          <div className="fu d2 rounded-xl border border-border bg-card p-5 md:p-7">
            <div className="flex items-center justify-between mb-5">
              <div className="flex items-center gap-2">
                <div className="w-1 h-4 rounded-full" style={{ background: RED }} />
                <h2 className="text-sm font-bold">{isArabic ? 'سجل الأسعار' : 'Price History'}</h2>
              </div>
              <div className="flex gap-1.5">
                {(['1Y','ALL'] as TF[]).map(t => (
                  <button key={t} onClick={() => setTf(t)}
                    className={`px-3 py-1 rounded-lg text-xs font-bold transition-all ${tf === t ? 'bg-foreground text-background' : 'bg-muted text-muted-foreground hover:text-foreground'}`}>
                    {t}
                  </button>
                ))}
              </div>
            </div>

            {chartData.length > 0 ? (
              <ResponsiveContainer width="100%" height={340}>
                <AreaChart data={chartData} margin={{ top: 8, right: 8, left: 0, bottom: 0 }}>
                  <defs>
                    <linearGradient id="grad" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%"  stopColor={accentColor} stopOpacity={0.18} />
                      <stop offset="95%" stopColor={accentColor} stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 5" stroke="rgba(0,0,0,.05)" />
                  <XAxis dataKey="date" tick={{ fontSize: 11, fill: '#aaa' }} tickLine={false} axisLine={false} />
                  <YAxis tick={{ fontSize: 11, fill: '#aaa' }} tickLine={false} axisLine={false} tickFormatter={v => fmt(v)} width={60} />
                  <Tooltip content={<CustomTooltip />} />
                  <Area type="monotone" dataKey="price" stroke={accentColor} strokeWidth={2.5}
                    fill="url(#grad)" dot={{ fill: accentColor, r: 4, strokeWidth: 2, stroke: '#fff' }}
                    activeDot={{ r: 6, fill: accentColor, stroke: '#fff', strokeWidth: 2 }} />
                </AreaChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-64 flex items-center justify-center text-muted-foreground text-sm">
                {isArabic ? 'لا توجد بيانات' : 'No chart data'}
              </div>
            )}
          </div>

          {/* description */}
          {latest.description && (
            <div className="fu d3 rounded-xl border border-border bg-card p-5" dir={isArabic ? 'rtl' : 'ltr'}>
              <div className="flex items-center gap-2 mb-3">
                <div className="w-1 h-4 rounded-full" style={{ background: RED }} />
                <h3 className="text-sm font-bold">{isArabic ? 'معلومات' : 'Information'}</h3>
              </div>
              <p className="text-sm text-muted-foreground leading-relaxed">{latest.description}</p>
            </div>
          )}

        </div>

        {/* right sidebar */}
        <div className="space-y-4">
          <AdSlot variant="sidebar" />

          {/* stats */}
          <div className="fu d2 p-4 rounded-xl border border-border bg-card">
            <h3 className="text-sm font-bold mb-3 flex items-center gap-2">
              <div className="w-1 h-3.5 rounded-full" style={{ background: RED }} />
              {isArabic ? 'إحصائيات' : 'Stats'}
            </h3>
            <div className="space-y-2.5 text-sm">
              {[
                { label: isArabic ? 'أعلى سعر' : 'High',  val: fmt(high) },
                { label: isArabic ? 'أقل سعر'  : 'Low',   val: fmt(low)  },
                { label: isArabic ? 'الوحدة'   : 'Unit',  val: latest.unit },
                { label: isArabic ? 'آخر تحديث': 'Updated', val: latest.date },
              ].map(r => (
                <div key={r.label} className="flex justify-between items-center border-b border-border pb-2 last:border-0 last:pb-0">
                  <span className="text-muted-foreground text-xs">{r.label}</span>
                  <span className="font-bold tabular-nums text-xs">{r.val}</span>
                </div>
              ))}
            </div>
          </div>

        </div>
      </div>
    </div>
  );
}
